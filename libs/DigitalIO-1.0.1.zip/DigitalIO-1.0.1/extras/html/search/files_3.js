var searchData=
[
  ['softi2cmaster_2ecpp',['SoftI2cMaster.cpp',['../_soft_i2c_master_8cpp.html',1,'']]],
  ['softi2cmaster_2eh',['SoftI2cMaster.h',['../_soft_i2c_master_8h.html',1,'']]],
  ['softspi_2eh',['SoftSPI.h',['../_soft_s_p_i_8h.html',1,'']]]
];
